﻿**PRACTICAL 1** 

**AIM: to Configure EC2 instance for window server using Aws** 

**Step 1:** enter your login and password and click on your course 

**Step 2**: after come in home page click on modules option as shown in below 

![](Aspose.Words.82d72d58-7efc-4ed0-aea1-ff864f61c2b6.001.png)

**Step 3**: click on launch aws academy learner lab 

![](Aspose.Words.82d72d58-7efc-4ed0-aea1-ff864f61c2b6.002.png)

**Step 4**:  as shown in below we click on star lab and wait until aws became green 

![](Aspose.Words.82d72d58-7efc-4ed0-aea1-ff864f61c2b6.003.png)

**Step 5**: after we click on aws bottom  

![](Aspose.Words.82d72d58-7efc-4ed0-aea1-ff864f61c2b6.004.png)

**Step 6**: next we come in console home page and click on all services** 

![](Aspose.Words.82d72d58-7efc-4ed0-aea1-ff864f61c2b6.005.jpeg)

**Step 7**: now we select EC2 

![](Aspose.Words.82d72d58-7efc-4ed0-aea1-ff864f61c2b6.006.png)

**Step 8**: here we can see that there are no instances are running, next we click on launch instance 

![](Aspose.Words.82d72d58-7efc-4ed0-aea1-ff864f61c2b6.007.png)

**Step 9**: first we enter a name for example: my server 

![](Aspose.Words.82d72d58-7efc-4ed0-aea1-ff864f61c2b6.008.png)

![](Aspose.Words.82d72d58-7efc-4ed0-aea1-ff864f61c2b6.009.jpeg)

**Step 10**: here we make Microsoft windows server so we click on it** 

![](Aspose.Words.82d72d58-7efc-4ed0-aea1-ff864f61c2b6.010.png)

**Step 11**: next we enter a key pair, it is allow you to your instance security 

![](Aspose.Words.82d72d58-7efc-4ed0-aea1-ff864f61c2b6.011.png)

**Step 12:** here we enter 29062014\_1 as a key pair 

![](Aspose.Words.82d72d58-7efc-4ed0-aea1-ff864f61c2b6.012.jpeg)

**Step 13**: next we enter launch instance  

![](Aspose.Words.82d72d58-7efc-4ed0-aea1-ff864f61c2b6.013.png)

![](Aspose.Words.82d72d58-7efc-4ed0-aea1-ff864f61c2b6.014.jpeg)

![](Aspose.Words.82d72d58-7efc-4ed0-aea1-ff864f61c2b6.015.jpeg)

**Step 14**: here we wait until status check passed 

![](Aspose.Words.82d72d58-7efc-4ed0-aea1-ff864f61c2b6.016.png)

**Step 15**: now we click on instance id 

![](Aspose.Words.82d72d58-7efc-4ed0-aea1-ff864f61c2b6.017.png)

![](Aspose.Words.82d72d58-7efc-4ed0-aea1-ff864f61c2b6.018.jpeg)

**Step 16**: now we click RDP client 

![](Aspose.Words.82d72d58-7efc-4ed0-aea1-ff864f61c2b6.019.png)

**Step 17**: now we enter a password so we click on upload private key file 

![](Aspose.Words.82d72d58-7efc-4ed0-aea1-ff864f61c2b6.020.png)

**Step 18**: now we click on decrypt password 

![](Aspose.Words.82d72d58-7efc-4ed0-aea1-ff864f61c2b6.021.jpeg)

**Step 19**: here we click on connect button for established connection 

![](Aspose.Words.82d72d58-7efc-4ed0-aea1-ff864f61c2b6.022.png)

**Step 20**: finally over virtual server is ready 

![](Aspose.Words.82d72d58-7efc-4ed0-aea1-ff864f61c2b6.023.jpeg)

**Step 21**: after we click on instance state to terminate instance  

![](Aspose.Words.82d72d58-7efc-4ed0-aea1-ff864f61c2b6.024.jpeg)

![](Aspose.Words.82d72d58-7efc-4ed0-aea1-ff864f61c2b6.025.png)
